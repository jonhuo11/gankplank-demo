﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum AnimationState
{
    RUNLEFT,
    RUNRIGHT,
    IDLELEFT,
    IDLERIGHT
}

// Player animation
public class PlayerAnimation : MonoBehaviour {
    // TODO: dict of {state : [material]}
    // conditions calculated inside Update, not animator itself
    public string animatorStateName = "State";
    public Material runRightMaterial;
    public Material runLeftMaterial;
    public Material idleRightMaterial;
    public Material idleLeftMaterial;
    
    public Vector2 velocityThresholds = new Vector2(0.1f, 0.1f);

    Animator anim;
    Rigidbody2D rbody;
    Renderer rend;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        rbody = GetComponent<Rigidbody2D>();
        rend = GetComponent<Renderer>();


        // default settings to avoid visual bug on first time
        ChangeState(AnimationState.IDLERIGHT, idleRightMaterial);
    }

    // Update is called once per frame
    void Update()
    {
        // based on velocity change animation
        Vector2 absVel = new Vector2(Mathf.Abs(rbody.velocity.x), Mathf.Abs(rbody.velocity.y));
        int state = anim.GetInteger(animatorStateName);

        // falling 
        if (absVel.y > velocityThresholds.y)
        {
            // TODO implement falling/jumping animation
        }
        else
        {
            // right
            if (rbody.velocity.x > velocityThresholds.x && state != (int)AnimationState.RUNRIGHT)
            {
                ChangeState(AnimationState.RUNRIGHT, runRightMaterial);
            }
            //left
            else if (rbody.velocity.x < -velocityThresholds.x && state != (int)AnimationState.RUNLEFT)
            {
                ChangeState(AnimationState.RUNLEFT, runLeftMaterial);
            }
            // idle right
            else if (state == (int)AnimationState.RUNRIGHT && (rbody.velocity.x < velocityThresholds.x && rbody.velocity.x >= 0))
            {
                ChangeState(AnimationState.IDLERIGHT, idleRightMaterial);
            }
            // idle left
            else if (state == (int)AnimationState.RUNLEFT && (rbody.velocity.x > -velocityThresholds.x && rbody.velocity.x <= 0))
            {
                ChangeState(AnimationState.IDLELEFT, idleLeftMaterial);
            }
        }
    }

    void ChangeState(AnimationState state, Material mat)
    {
        anim.SetInteger(animatorStateName, (int)state);
        rend.material = mat;
    }
}
